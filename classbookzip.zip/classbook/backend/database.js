// ============================================================
// DATABASE.JS — VIT Pune | FY CSAIML A-F | Semester 1 | 2026-27
// ============================================================

const bcrypt = require('bcryptjs');
const { SEED_PASSWORD } = require('./config');

// Hash once, reuse for every seeded account (password comes from env, never hard-coded)
const SEED_HASH = bcrypt.hashSync(SEED_PASSWORD, 10);

// ---- USERS ----
const users = [
  { id: 'AMK', username: 'amk', password: SEED_HASH, name: 'Dr. Ashutosh Kulkarni',    role: 'teacher' },
  { id: 'DSP', username: 'dsp', password: SEED_HASH, name: 'Dr. Uma S. Patil',         role: 'teacher' },
  { id: 'SAB', username: 'sab', password: SEED_HASH, name: 'Mrs. Sayali Belhe',        role: 'teacher' },
  { id: 'PSG', username: 'psg', password: SEED_HASH, name: 'Mrs. Pooja Gavhane',       role: 'teacher' },
  { id: 'KVW', username: 'kvw', password: SEED_HASH, name: 'Mrs. Kanchan Wankhade',    role: 'teacher' },
  { id: 'VKI', username: 'vki', password: SEED_HASH, name: 'Mr. Vijay Itnal',          role: 'teacher' },
  { id: 'STB', username: 'stb', password: SEED_HASH, name: 'Mr. Sahebrao Bhalshankar', role: 'teacher' },
  { id: 'GMV', username: 'gmv', password: SEED_HASH, name: 'Dr. Manasi Ghamande',      role: 'teacher' },
  { id: 'SPM', username: 'spm', password: SEED_HASH, name: 'Mrs. Supriya Mandhare',    role: 'teacher' },
  { id: 'GZZ', username: 'gzz', password: SEED_HASH, name: 'Ms. Geeta Zaware',         role: 'teacher' },
  { id: 'MAM', username: 'mam', password: SEED_HASH, name: 'Mrs. Madhavi Mohite',      role: 'teacher' },
  { id: 'ADL', username: 'adl', password: SEED_HASH, name: 'Mr. Amol Ladhe',           role: 'teacher' },
  { id: 'RJD', username: 'rjd', password: SEED_HASH, name: 'Dr. Rajesh Dhake',         role: 'teacher' },
  { id: 'SMP', username: 'smp', password: SEED_HASH, name: 'Mrs. Sneha Patil',         role: 'teacher' },
  { id: 'NPR', username: 'npr', password: SEED_HASH, name: 'Mrs. Neha Rajas',          role: 'teacher' },
  { id: 'PPR', username: 'ppr', password: SEED_HASH, name: 'Mr. Praveen Rathod',       role: 'teacher' },
  { id: 'PAP', username: 'pap', password: SEED_HASH, name: 'Mrs. Prachi Pawar',        role: 'teacher' },
  { id: 'VSJ', username: 'vsj', password: SEED_HASH, name: 'Dr. Vaishali Jabade',      role: 'teacher' },
  { id: 'KVJ', username: 'kvj', password: SEED_HASH, name: 'Mr. Kalpesh Joshi',        role: 'teacher' },
  // ---- STUDENTS — Division-wise (AIML A to F) ----
  { id: 'SA1', username: 'aiml_a1', password: SEED_HASH, name: 'AIML-A Student 1', role: 'student', division: 'A' },
  { id: 'SA2', username: 'aiml_a2', password: SEED_HASH, name: 'AIML-A Student 2', role: 'student', division: 'A' },
  { id: 'SB1', username: 'aiml_b1', password: SEED_HASH, name: 'AIML-B Student 1', role: 'student', division: 'B' },
  { id: 'SB2', username: 'aiml_b2', password: SEED_HASH, name: 'AIML-B Student 2', role: 'student', division: 'B' },
  { id: 'SC1', username: 'aiml_c1', password: SEED_HASH, name: 'AIML-C Student 1', role: 'student', division: 'C' },
  { id: 'SC2', username: 'aiml_c2', password: SEED_HASH, name: 'AIML-C Student 2', role: 'student', division: 'C' },
  { id: 'SD1', username: 'aiml_d1', password: SEED_HASH, name: 'AIML-D Student 1', role: 'student', division: 'D' },
  { id: 'SD2', username: 'aiml_d2', password: SEED_HASH, name: 'AIML-D Student 2', role: 'student', division: 'D' },
  { id: 'SE1', username: 'aiml_e1', password: SEED_HASH, name: 'AIML-E Student 1', role: 'student', division: 'E' },
  { id: 'SE2', username: 'aiml_e2', password: SEED_HASH, name: 'AIML-E Student 2', role: 'student', division: 'E' },
  { id: 'SF1', username: 'aiml_f1', password: SEED_HASH, name: 'AIML-F Student 1', role: 'student', division: 'F' },
  { id: 'SF2', username: 'aiml_f2', password: SEED_HASH, name: 'AIML-F Student 2', role: 'student', division: 'F' },
];

// ---- ROOMS ----
// Naming: first digit = building (1-4), second digit = floor, rest = room number
const rooms = [
  // BUILDING 1 — Floor 0
  { id: '1001', name: 'Room 1001', capacity: 60, building: 'Building 1', floor: 'Ground Floor', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1002', name: 'Room 1002', capacity: 60, building: 'Building 1', floor: 'Ground Floor', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  // BUILDING 1 — Floor 1
  { id: '1102', name: 'Room 1102', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1103', name: 'Room 1103', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1107', name: 'Room 1107', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1109', name: 'Room 1109', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1115', name: 'Room 1115', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1116', name: 'Room 1116', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1123', name: 'Room 1123', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1124', name: 'Room 1124', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1125', name: 'Room 1125', capacity: 60, building: 'Building 1', floor: 'Floor 1', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  // BUILDING 1 — Floor 2
  { id: '1213ALAB', name: 'Lab 1213A',  capacity: 30, building: 'Building 1', floor: 'Floor 2', type: 'Lab', facilities: ['Computers','Projector'] },
  { id: '1214',     name: 'Room 1214',  capacity: 60, building: 'Building 1', floor: 'Floor 2', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1220A',    name: 'Room 1220A', capacity: 60, building: 'Building 1', floor: 'Floor 2', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1223',     name: 'Room 1223',  capacity: 40, building: 'Building 1', floor: 'Floor 2', type: 'Tutorial', facilities: ['Whiteboard'] },
  { id: '1224',     name: 'Room 1224',  capacity: 60, building: 'Building 1', floor: 'Floor 2', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  { id: '1225',     name: 'Room 1225',  capacity: 40, building: 'Building 1', floor: 'Floor 2', type: 'Tutorial', facilities: ['Whiteboard'] },
  // BUILDING 1 — Floor 3
  { id: '1303', name: 'Room 1303', capacity: 40, building: 'Building 1', floor: 'Floor 3', type: 'Tutorial', facilities: ['Whiteboard'] },
  // BUILDING 1 — Floor 4
  { id: '1401', name: 'Room 1401', capacity: 40, building: 'Building 1', floor: 'Floor 4', type: 'Tutorial', facilities: ['Whiteboard'] },
  { id: '1404', name: 'Room 1404', capacity: 60, building: 'Building 1', floor: 'Floor 4', type: 'Theory',   facilities: ['Projector','Whiteboard'] },
  // BUILDING 2 — (placeholder rooms for booking)
  { id: '2101', name: 'Room 2101', capacity: 60, building: 'Building 2', floor: 'Floor 1', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  { id: '2102', name: 'Room 2102', capacity: 60, building: 'Building 2', floor: 'Floor 1', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  { id: '2201', name: 'Room 2201', capacity: 60, building: 'Building 2', floor: 'Floor 2', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  { id: '2301', name: 'Room 2301', capacity: 60, building: 'Building 2', floor: 'Floor 3', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  // BUILDING 3
  { id: '3101', name: 'Room 3101', capacity: 60, building: 'Building 3', floor: 'Floor 1', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  { id: '3201', name: 'Room 3201', capacity: 60, building: 'Building 3', floor: 'Floor 2', type: 'Theory', facilities: ['Projector','Whiteboard'] },
  // BUILDING 4 — Floor 3
  { id: '4309', name: 'Lab 4309', capacity: 30, building: 'Building 4', floor: 'Floor 3', type: 'Lab', facilities: ['Computers','Projector'] },
];

// ---- TIME SLOTS ----
const slots = [
  '08:00-09:00','09:00-10:00','10:00-11:00','11:00-12:00',
  '12:00-13:00','13:00-14:00','14:00-15:00','15:00-16:00',
  '16:00-17:00','17:00-18:00'
];

const days = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

// ---- BOOKINGS ----
const bookings = {};

function seedTimetable() {
  const tt = [
    // DIV A — Monday
    {r:'1125',d:'Monday',s:'08:00-09:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B1)',div:'A'},
    {r:'1125',d:'Monday',s:'09:00-10:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B1)',div:'A'},
    {r:'1124',d:'Monday',s:'10:00-11:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'A'},
    {r:'1303',d:'Monday',s:'11:00-12:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra Tut (B3)',div:'A'},
    {r:'1002',d:'Monday',s:'13:00-14:00',t:'AMK',tn:'Dr. Ashutosh Kulkarni',sub:'Indian Knowledge System',div:'A'},
    {r:'1002',d:'Monday',s:'14:00-15:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'A'},
    // DIV A — Tuesday
    {r:'1125',d:'Tuesday',s:'08:00-09:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'A'},
    {r:'1124',d:'Tuesday',s:'09:00-10:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'A'},
    {r:'1125',d:'Tuesday',s:'10:00-11:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B2)',div:'A'},
    {r:'1213ALAB',d:'Tuesday',s:'11:00-12:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B3)',div:'A'},
    {r:'1125',d:'Tuesday',s:'12:00-13:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B2)',div:'A'},
    {r:'1213ALAB',d:'Tuesday',s:'13:00-14:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B3)',div:'A'},
    // DIV A — Wednesday
    {r:'1125',d:'Wednesday',s:'08:00-09:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'A'},
    {r:'1125',d:'Wednesday',s:'09:00-10:00',t:'STB',tn:'Mr. Sahebrao Bhalshankar',sub:'Sci Research Methods-2',div:'A'},
    {r:'1103',d:'Wednesday',s:'11:00-12:00',t:'GMV',tn:'Dr. Manasi Ghamande',sub:'Student Activity',div:'A'},
    {r:'1213ALAB',d:'Wednesday',s:'12:00-13:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Lab (B1)',div:'A'},
    {r:'1213ALAB',d:'Wednesday',s:'13:00-14:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Lab (B1)',div:'A'},
    {r:'4309',d:'Wednesday',s:'14:00-15:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B2)',div:'A'},
    {r:'4309',d:'Wednesday',s:'15:00-16:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B2)',div:'A'},
    // DIV A — Thursday
    {r:'1124',d:'Thursday',s:'09:00-10:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra Tut (B1)',div:'A'},
    {r:'1125',d:'Thursday',s:'11:00-12:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Reasoning & Aptitude Dev-2',div:'A'},
    {r:'1124',d:'Thursday',s:'12:00-13:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'A'},
    {r:'1303',d:'Thursday',s:'13:00-14:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra Tut (B2)',div:'A'},
    // DIV A — Friday
    {r:'1107',d:'Friday',s:'08:00-09:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B3)',div:'A'},
    {r:'1107',d:'Friday',s:'09:00-10:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'GP-2 Lab (B3)',div:'A'},
    {r:'1125',d:'Friday',s:'10:00-11:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'A'},
    {r:'1124',d:'Friday',s:'11:00-12:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Theory',div:'A'},
    {r:'1125',d:'Friday',s:'12:00-13:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'A'},

    // DIV B — Monday
    {r:'1109',d:'Monday',s:'08:00-09:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Reasoning & Aptitude Dev-2',div:'B'},
    {r:'1109',d:'Monday',s:'09:00-10:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Comp Org & Arch',div:'B'},
    {r:'1124',d:'Monday',s:'10:00-11:00',t:'GZZ',tn:'Ms. Geeta Zaware',sub:'PS&P Theory',div:'B'},
    {r:'1223',d:'Monday',s:'14:00-15:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra Tut (B2)',div:'B'},
    // DIV B — Tuesday
    {r:'1125',d:'Tuesday',s:'08:00-09:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Comp Org & Arch',div:'B'},
    {r:'1303',d:'Tuesday',s:'13:00-14:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra Tut (B3)',div:'B'},
    // DIV B — Wednesday
    {r:'1125',d:'Wednesday',s:'11:00-12:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Web Dev Theory',div:'B'},
    {r:'1125',d:'Wednesday',s:'12:00-13:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'B'},
    // DIV B — Thursday
    {r:'1125',d:'Thursday',s:'10:00-11:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'B'},
    {r:'1125',d:'Thursday',s:'11:00-12:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'Indian Knowledge System',div:'B'},
    // DIV B — Friday
    {r:'1125',d:'Friday',s:'08:00-09:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'B'},
    {r:'1125',d:'Friday',s:'09:00-10:00',t:'STB',tn:'Mr. Sahebrao Bhalshankar',sub:'Sci Research Methods-2',div:'B'},

    // DIV C — Monday
    {r:'1002',d:'Monday',s:'10:00-11:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'C'},
    {r:'1124',d:'Monday',s:'12:00-13:00',t:'RJD',tn:'Dr. Rajesh Dhake',sub:'Student Activity',div:'C'},
    {r:'1124',d:'Monday',s:'13:00-14:00',t:'STB',tn:'Mr. Sahebrao Bhalshankar',sub:'Web Dev Theory',div:'C'},
    {r:'1125',d:'Monday',s:'14:00-15:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'C'},
    // DIV C — Tuesday
    {r:'1303',d:'Tuesday',s:'11:00-12:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B1)',div:'C'},
    {r:'1123',d:'Tuesday',s:'12:00-13:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Comp Org & Arch',div:'C'},
    // DIV C — Wednesday
    {r:'1002',d:'Wednesday',s:'08:00-09:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B3)',div:'C'},
    {r:'1102',d:'Wednesday',s:'12:00-13:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Comp Org & Arch',div:'C'},
    {r:'1125',d:'Wednesday',s:'13:00-14:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'C'},
    // DIV C — Thursday
    {r:'1002',d:'Thursday',s:'08:00-09:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'C'},
    {r:'1303',d:'Thursday',s:'11:00-12:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B2)',div:'C'},
    // DIV C — Friday
    {r:'1124',d:'Friday',s:'10:00-11:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'PS&P Theory',div:'C'},
    {r:'1124',d:'Friday',s:'11:00-12:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'Indian Knowledge System',div:'C'},
    {r:'1124',d:'Friday',s:'12:00-13:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Reasoning & Aptitude Dev-2',div:'C'},
    {r:'1224',d:'Friday',s:'13:00-14:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'C'},

    // DIV D — Monday
    {r:'1109',d:'Monday',s:'10:00-11:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'PS&P Theory',div:'D'},
    {r:'1109',d:'Monday',s:'13:00-14:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'D'},
    // DIV D — Tuesday
    {r:'1109',d:'Tuesday',s:'08:00-09:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'Indian Knowledge System',div:'D'},
    {r:'1109',d:'Tuesday',s:'09:00-10:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'D'},
    {r:'1404',d:'Tuesday',s:'10:00-11:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Reasoning & Aptitude Dev-2',div:'D'},
    // DIV D — Wednesday
    {r:'1124',d:'Wednesday',s:'08:00-09:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'PS&P Theory',div:'D'},
    {r:'1401',d:'Wednesday',s:'09:00-10:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B3)',div:'D'},
    {r:'1224',d:'Wednesday',s:'10:00-11:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'D'},
    {r:'1125',d:'Wednesday',s:'14:00-15:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Web Dev Theory',div:'D'},
    // DIV D — Thursday
    {r:'1002',d:'Thursday',s:'11:00-12:00',t:'RJD',tn:'Dr. Rajesh Dhake',sub:'Student Activity',div:'D'},
    {r:'1103',d:'Thursday',s:'12:00-13:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'PS&P Theory',div:'D'},
    {r:'1102',d:'Thursday',s:'16:00-17:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B2)',div:'D'},
    // DIV D — Friday
    {r:'1214',d:'Friday',s:'08:00-09:00',t:'NPR',tn:'Mrs. Neha Rajas',sub:'Sci Research Methods-2',div:'D'},
    {r:'1001',d:'Friday',s:'09:00-10:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'D'},

    // DIV E — Monday
    {r:'1303',d:'Monday',s:'08:00-09:00',t:'ADL',tn:'Mr. Amol Ladhe',sub:'GP-2 Lab (B3)',div:'E'},
    {r:'1303',d:'Monday',s:'09:00-10:00',t:'ADL',tn:'Mr. Amol Ladhe',sub:'GP-2 Lab (B3)',div:'E'},
    {r:'1116',d:'Monday',s:'11:00-12:00',t:'RJD',tn:'Dr. Rajesh Dhake',sub:'Student Activity',div:'E'},
    {r:'1116',d:'Monday',s:'12:00-13:00',t:'STB',tn:'Mr. Sahebrao Bhalshankar',sub:'Web Dev Theory',div:'E'},
    {r:'1116',d:'Monday',s:'13:00-14:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'E'},
    {r:'1124',d:'Monday',s:'14:00-15:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'Indian Knowledge System',div:'E'},
    // DIV E — Tuesday
    {r:'1224',d:'Tuesday',s:'08:00-09:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'E'},
    // DIV E — Wednesday
    {r:'1109',d:'Wednesday',s:'08:00-09:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Theory',div:'E'},
    {r:'1404',d:'Wednesday',s:'10:00-11:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'Comp Org & Arch',div:'E'},
    // DIV E — Thursday
    {r:'1125',d:'Thursday',s:'13:00-14:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Theory',div:'E'},
    // DIV E — Friday
    {r:'1002',d:'Friday',s:'10:00-11:00',t:'PSG',tn:'Mrs. Pooja Gavhane',sub:'Linear Algebra',div:'E'},
    {r:'1124',d:'Friday',s:'11:00-12:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Theory',div:'E'},
    {r:'1124',d:'Friday',s:'12:00-13:00',t:'STB',tn:'Mr. Sahebrao Bhalshankar',sub:'Sci Research Methods-2',div:'E'},
    {r:'1124',d:'Friday',s:'13:00-14:00',t:'PPR',tn:'Mr. Praveen Rathod',sub:'Reasoning & Aptitude Dev-2',div:'E'},

    // DIV F — Monday
    {r:'1125',d:'Monday',s:'10:00-11:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B3)',div:'F'},
    {r:'1125',d:'Monday',s:'11:00-12:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'F'},
    {r:'1109',d:'Monday',s:'12:00-13:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'PS&P Theory',div:'F'},
    // DIV F — Tuesday
    {r:'1116',d:'Tuesday',s:'09:00-10:00',t:'RJD',tn:'Dr. Rajesh Dhake',sub:'Student Activity',div:'F'},
    {r:'1124',d:'Tuesday',s:'10:00-11:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'PS&P Theory',div:'F'},
    // DIV F — Wednesday
    {r:'1001',d:'Wednesday',s:'09:00-10:00',t:'PAP',tn:'Mrs. Prachi Pawar',sub:'Comp Org & Arch',div:'F'},
    {r:'1125',d:'Wednesday',s:'10:00-11:00',t:'SMP',tn:'Mrs. Sneha Patil',sub:'Sci Research Methods-2',div:'F'},
    // DIV F — Thursday
    {r:'1001',d:'Thursday',s:'08:00-09:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra',div:'F'},
    {r:'1001',d:'Thursday',s:'09:00-10:00',t:'PAP',tn:'Mrs. Prachi Pawar',sub:'Comp Org & Arch',div:'F'},
    {r:'1124',d:'Thursday',s:'10:00-11:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Reasoning & Aptitude Dev-2',div:'F'},
    {r:'1124',d:'Thursday',s:'11:00-12:00',t:'VKI',tn:'Mr. Vijay Itnal',sub:'Indian Knowledge System',div:'F'},
    {r:'1124',d:'Thursday',s:'12:00-13:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Web Dev Theory',div:'F'},
    // DIV F — Friday
    {r:'1115',d:'Friday',s:'10:00-11:00',t:'MAM',tn:'Mrs. Madhavi Mohite',sub:'Linear Algebra Tut (B1)',div:'F'},

    // SHARED LAB SLOTS (appear in multiple divisions)
    // Lab 1213A
    {r:'1213ALAB',d:'Thursday',s:'08:00-09:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Lab (B2) - Div A',div:'A'},
    {r:'1213ALAB',d:'Thursday',s:'09:00-10:00',t:'DSP',tn:'Dr. Uma S. Patil',sub:'PS&P Lab (B2) - Div A',div:'A'},
    // Lab 4309
    {r:'4309',d:'Monday',s:'14:00-15:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Web Dev Lab (B2) - Div D',div:'D'},
    {r:'4309',d:'Monday',s:'15:00-16:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Web Dev Lab (B2) - Div D',div:'D'},
    {r:'4309',d:'Thursday',s:'12:00-13:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Web Dev Lab (B1) - Div B',div:'B'},
    {r:'4309',d:'Thursday',s:'13:00-14:00',t:'SPM',tn:'Mrs. Supriya Mandhare',sub:'Web Dev Lab (B1) - Div B',div:'B'},
    {r:'4309',d:'Friday',s:'08:00-09:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Web Dev Lab (B1) - Div F',div:'F'},
    {r:'4309',d:'Friday',s:'09:00-10:00',t:'KVW',tn:'Mrs. Kanchan Wankhade',sub:'Web Dev Lab (B1) - Div F',div:'F'},
    {r:'4309',d:'Friday',s:'11:00-12:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B2) - Div F',div:'F'},
    {r:'4309',d:'Friday',s:'12:00-13:00',t:'SAB',tn:'Mrs. Sayali Belhe',sub:'Web Dev Lab (B2) - Div F',div:'F'},
  ];

  tt.forEach(b => {
    const key = `${b.r}|${b.d}|${b.s}`;
    if (!bookings[key]) {
      bookings[key] = {
        id: key,
        roomId: b.r, day: b.d, slot: b.s,
        teacherId: b.t, teacherName: b.tn,
        subject: `[Div ${b.div}] ${b.sub}`,
        division: b.div,
        type: 'timetable',
        createdAt: new Date().toISOString()
      };
    }
  });
}
seedTimetable();

// ---- WAITLISTS ----
const waitlists = {};

// ---- NOTIFICATIONS ----
const notifications = [];

module.exports = { users, rooms, slots, days, bookings, waitlists, notifications };
