// ============================================================
// CONFIG.JS — All settings come from environment variables
// (locally: backend/.env file | deployed: host dashboard)
// ============================================================

require('dotenv').config({ quiet: true });
const crypto = require('crypto');

const isProd = process.env.NODE_ENV === 'production';
const warn = (msg) => console.warn(`⚠️  ${msg}`);

// ---- JWT secret ----
// Used to sign login tokens. Never hard-code this in the source.
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  JWT_SECRET = crypto.randomBytes(48).toString('hex');
  warn('JWT_SECRET is missing or shorter than 32 characters — using a random one for this run. ' +
       'Everyone gets logged out when the server restarts. Set JWT_SECRET in your environment.');
}

// ---- Password given to all seeded demo accounts ----
let SEED_PASSWORD = process.env.SEED_PASSWORD;
if (!SEED_PASSWORD) {
  if (isProd) {
    console.error('❌ SEED_PASSWORD is required when NODE_ENV=production. Set it in your host\'s environment variables.');
    process.exit(1);
  }
  SEED_PASSWORD = 'pass123';
  warn('SEED_PASSWORD not set — using the default dev password (fine for local use only).');
} else if (isProd && SEED_PASSWORD.length < 8) {
  console.error('❌ SEED_PASSWORD must be at least 8 characters in production.');
  process.exit(1);
}

// ---- Trust proxy (needed on Render / Railway / Heroku etc. so IPs & https are detected correctly) ----
let TRUST_PROXY = process.env.TRUST_PROXY;
if (TRUST_PROXY === undefined) TRUST_PROXY = isProd ? 1 : false;
else if (/^\d+$/.test(TRUST_PROXY)) TRUST_PROXY = Number(TRUST_PROXY);
else if (TRUST_PROXY === 'true') TRUST_PROXY = true;
else if (TRUST_PROXY === 'false') TRUST_PROXY = false;

// ---- CORS allow-list (only needed if the frontend is hosted on a DIFFERENT origin) ----
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ||
  (isProd ? '' : 'http://localhost:3000,http://127.0.0.1:3000'))
  .split(',').map(s => s.trim()).filter(Boolean);

// ---- Semester window (kept same as before unless you override) ----
// Academic Year 2026-27 Sem I: teaching starts 6 Jul 2026, internal assessment ends 21 Nov 2026
const SEMESTER_START = process.env.SEMESTER_START || '2026-07-06';
const SEMESTER_END   = process.env.SEMESTER_END   || '2026-11-21';
const SEMESTER_LABEL = process.env.SEMESTER_LABEL || 'Semester 1 (6 Jul – 21 Nov 2026)';

// Holidays from the academic calendar (no bookings on these dates). Override: HOLIDAYS=2026-10-02,2026-10-20
const DEFAULT_HOLIDAYS = [
  '2026-08-15', '2026-08-26', '2026-09-14', '2026-09-18', '2026-09-25', '2026-10-02', '2026-10-20',
  '2026-11-06', '2026-11-07', '2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11', '2026-11-12',
  '2026-11-24', '2026-12-25'
];
const HOLIDAYS = process.env.HOLIDAYS
  ? process.env.HOLIDAYS.split(',').map(s => s.trim()).filter(Boolean)
  : DEFAULT_HOLIDAYS;
const WEEKLY_BOOKING_LIMIT = parseInt(process.env.WEEKLY_BOOKING_LIMIT, 10) || 2;

// Timezone used for "is this slot already over?" checks (server may run in UTC)
const TIMEZONE = process.env.TIMEZONE || 'Asia/Kolkata';

module.exports = {
  isProd,
  TIMEZONE,
  PORT: parseInt(process.env.PORT, 10) || 5000,
  JWT_SECRET,
  SEED_PASSWORD,
  TRUST_PROXY,
  ALLOWED_ORIGINS,
  SEMESTER_START, SEMESTER_END, SEMESTER_LABEL, HOLIDAYS, WEEKLY_BOOKING_LIMIT,
  COOKIE_NAME: 'cb_session',
  TOKEN_TTL_HOURS: 8
};
