// ============================================================
// SERVER.JS — Main Express Server for ClassBook
// ============================================================

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { rateLimit, ipKeyGenerator } = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const cfg = require('./config');
const { users, rooms, slots, days, bookings, waitlists, notifications } = require('./database');

const app = express();
const SEMESTER_START = new Date(`${cfg.SEMESTER_START}T00:00:00`);
const SEMESTER_END   = new Date(`${cfg.SEMESTER_END}T23:59:59`);
const WEEKLY_BOOKING_LIMIT = cfg.WEEKLY_BOOKING_LIMIT;
const DIVISIONS = ['A', 'B', 'C', 'D', 'E', 'F'];
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend', 'public');

app.disable('x-powered-by');
app.set('trust proxy', cfg.TRUST_PROXY);

// ============================================================
// SECURITY HEADERS (helmet) + strict Content-Security-Policy
// ============================================================
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'script-src-attr': ["'none'"],          // no inline onclick="" handlers allowed
      'style-src': ["'self'", "'unsafe-inline'"],
      'img-src': ["'self'", 'data:'],
      'connect-src': ["'self'"],
      'object-src': ["'none'"],
      'base-uri': ["'self'"],
      'form-action': ["'self'"],
      'frame-ancestors': ["'none'"],
      'upgrade-insecure-requests': cfg.isProd ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false
}));

// ============================================================
// CORS — only needed if frontend runs on another origin (local dev: port 3000)
// ============================================================
app.use('/api', cors({
  origin: (origin, cb) => cb(null, !origin || cfg.ALLOWED_ORIGINS.includes(origin)),
  credentials: true
}));

app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());

// Never let browsers/proxies cache API responses
app.use('/api', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// CSRF guard: state-changing requests must come from our own site (cookie is also SameSite=Strict)
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (!origin) return next();
  let ok = cfg.ALLOWED_ORIGINS.includes(origin);
  try { ok = ok || new URL(origin).host === req.get('host'); } catch { ok = false; }
  if (!ok) return res.status(403).json({ error: 'Request blocked' });
  next();
});

// ============================================================
// RATE LIMITING
// ============================================================
const rateMsg = (error) => ({ error });

// General API limit (generous — shared college Wi-Fi means many users share one IP)
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  limit: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: rateMsg('Too many requests. Please slow down.')
}));

// Login: failed attempts only. Limited per (IP + username) and per IP overall.
const loginLimiterPerUser = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) =>
    `${ipKeyGenerator(req.ip)}|${String(req.body?.username || '').toLowerCase().slice(0, 50)}`,
  message: rateMsg('Too many failed attempts for this account. Try again in 15 minutes.')
});
const loginLimiterPerIp = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 60,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: rateMsg('Too many failed login attempts. Try again in 15 minutes.')
});

// ============================================================
// SESSION HELPERS (JWT stored in an httpOnly cookie — JavaScript can't read it)
// ============================================================
const TOKEN_TTL_MS = cfg.TOKEN_TTL_HOURS * 60 * 60 * 1000;
const revokedTokens = new Map(); // jti -> expiry (ms)  — filled on logout
setInterval(() => {
  const now = Date.now();
  for (const [jti, exp] of revokedTokens) if (exp < now) revokedTokens.delete(jti);
}, 10 * 60 * 1000).unref();

function cookieOptions(req) {
  return {
    httpOnly: true,
    sameSite: 'strict',
    secure: req.secure,      // true automatically on https
    path: '/'
  };
}

function readSession(req) {
  const token = req.cookies?.[cfg.COOKIE_NAME];
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, cfg.JWT_SECRET, { algorithms: ['HS256'], issuer: 'classbook' });
    if (revokedTokens.has(decoded.jti)) return null;
    return decoded;
  } catch {
    return null;
  }
}

// ============================================================
// MIDDLEWARE
// ============================================================
function authMiddleware(req, res, next) {
  const decoded = readSession(req);
  if (!decoded) return res.status(401).json({ error: 'Please sign in' });
  req.user = decoded;
  next();
}

function teacherOnly(req, res, next) {
  if (req.user.role !== 'teacher') {
    return res.status(403).json({ error: 'Teachers only' });
  }
  next();
}

// ============================================================
// SMALL HELPERS
// ============================================================
const isStr = (v) => typeof v === 'string';

// Trim, drop control characters, cap length
function cleanText(v, max) {
  return String(v).replace(/[\u0000-\u001F\u007F]/g, ' ').trim().slice(0, max);
}

function isValidDateStr(s) {
  if (!isStr(s) || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  // Compare in UTC so the check gives the same answer on every server timezone (IST, UTC, ...)
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

// Current date (YYYY-MM-DD) and minutes-since-midnight in the college timezone (IST by default)
function nowInZone() {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: cfg.TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  }).formatToParts(new Date()).map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, minutes: parseInt(p.hour, 10) * 60 + parseInt(p.minute, 10) };
}

// '08:00-09:00' -> 480
function slotStartMinutes(slot) {
  const [h, m] = slot.split('-')[0].split(':').map(Number);
  return h * 60 + m;
}

function pushNotification(n) {
  notifications.push(n);
  if (notifications.length > 5000) notifications.splice(0, notifications.length - 5000);
}

// Get ISO week number (Mon-Sun)
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// Parse a date from booking (stored as ISO string)
function weekKey(isoString) {
  const d = new Date(isoString);
  return `${d.getFullYear()}-W${getWeekNumber(d)}`;
}

function extraBookingsThisWeek(teacherId) {
  const now = new Date();
  const currentWeek = `${now.getFullYear()}-W${getWeekNumber(now)}`;
  return Object.values(bookings).filter(b =>
    b.teacherId === teacherId &&
    b.type === 'extra' &&
    weekKey(b.createdAt) === currentWeek
  );
}

// ============================================================
// AUTH ROUTES
// ============================================================

// Compared against when the username doesn't exist, so response time doesn't reveal valid usernames
const DUMMY_HASH = bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), 10);

// POST /api/auth/login
app.post('/api/auth/login', loginLimiterPerIp, loginLimiterPerUser, async (req, res, next) => {
  try {
    const { username, password, expectedRole } = req.body || {};
    if (!isStr(username) || !isStr(password) || !username.trim() || !password)
      return res.status(400).json({ error: 'Username and password required' });
    if (username.length > 50 || password.length > 128)
      return res.status(400).json({ error: 'Invalid username or password' });
    if (expectedRole !== undefined && expectedRole !== null && !['teacher', 'student'].includes(expectedRole))
      return res.status(400).json({ error: 'Invalid role' });

    const uname = username.trim().toLowerCase();
    const user = users.find(u => u.username === uname);
    const passwordOk = await bcrypt.compare(password, user ? user.password : DUMMY_HASH);
    if (!user || !passwordOk)
      return res.status(401).json({ error: 'Invalid username or password' });

    // Role mismatch check — teacher tab se student login nahi hoga aur vice versa
    if (expectedRole && user.role !== expectedRole) {
      const msg = user.role === 'teacher'
        ? 'This account is a Teacher account. Please use the Teacher tab.'
        : 'This account is a Student account. Please use the Student tab.';
      return res.status(403).json({ error: msg });
    }

    const token = jwt.sign(
      { id: user.id, name: user.name, role: user.role, division: user.division || null },
      cfg.JWT_SECRET,
      { algorithm: 'HS256', expiresIn: `${cfg.TOKEN_TTL_HOURS}h`, issuer: 'classbook', jwtid: uuidv4() }
    );

    // Token goes ONLY in an httpOnly cookie — not in the response body, not in localStorage
    res.cookie(cfg.COOKIE_NAME, token, { ...cookieOptions(req), maxAge: TOKEN_TTL_MS });
    res.json({
      user: { id: user.id, name: user.name, username: user.username, role: user.role, division: user.division || null }
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/auth/me — get current user info
app.get('/api/auth/me', authMiddleware, (req, res) => {
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(401).json({ error: 'Please sign in' });
  res.json({
    user: { id: user.id, name: user.name, username: user.username, role: user.role, division: user.division || null }
  });
});

// POST /api/auth/logout — invalidates the token on the server too
app.post('/api/auth/logout', (req, res) => {
  const decoded = readSession(req);
  if (decoded) revokedTokens.set(decoded.jti, decoded.exp * 1000);
  res.clearCookie(cfg.COOKIE_NAME, cookieOptions(req));
  res.json({ message: 'Signed out' });
});

// ============================================================
// ROOMS ROUTES
// ============================================================

// GET /api/rooms — list all rooms
app.get('/api/rooms', authMiddleware, (req, res) => {
  res.json({ rooms });
});

// GET /api/rooms/availability?day=Monday&slot=09:00-10:00
app.get('/api/rooms/availability', authMiddleware, (req, res) => {
  const { day, slot, minCapacity } = req.query;
  if (!isStr(day) || !isStr(slot) || !day || !slot)
    return res.status(400).json({ error: 'day and slot are required' });
  if (!days.includes(day)) return res.status(400).json({ error: 'Invalid day' });
  if (!slots.includes(slot)) return res.status(400).json({ error: 'Invalid slot' });

  let filtered = rooms;
  const minCap = parseInt(minCapacity, 10);
  if (minCap > 0) filtered = filtered.filter(r => r.capacity >= minCap);

  const result = filtered.map(room => {
    const key = `${room.id}|${day}|${slot}`;
    const booking = bookings[key] || null;
    const waitlist = waitlists[key] || [];
    return {
      ...room,
      booking,
      waitlistCount: waitlist.length,
      isAvailable: !booking
    };
  });

  res.json({ rooms: result, day, slot, now: nowInZone() });
});

// ============================================================
// BOOKINGS ROUTES
// ============================================================

// GET /api/bookings — get all bookings (for timetable view)
app.get('/api/bookings', authMiddleware, (req, res) => {
  const { day } = req.query;
  let result = Object.values(bookings);
  if (isStr(day) && day) result = result.filter(b => b.day === day);
  res.json({ bookings: result });
});

// GET /api/bookings/weekly-count — how many extra bookings this teacher made this week
app.get('/api/bookings/weekly-count', authMiddleware, teacherOnly, (req, res) => {
  res.json({ count: extraBookingsThisWeek(req.user.id).length, limit: WEEKLY_BOOKING_LIMIT });
});

// GET /api/bookings/mine — get current teacher's bookings
app.get('/api/bookings/mine', authMiddleware, teacherOnly, (req, res) => {
  const mine = Object.values(bookings).filter(b => b.teacherId === req.user.id);
  res.json({ bookings: mine });
});

// POST /api/bookings — create a new booking
app.post('/api/bookings', authMiddleware, teacherOnly, (req, res) => {
  const { roomId, day, slot, subject, bookingDate, targetDivision } = req.body || {};
  if (!isStr(roomId) || !isStr(day) || !isStr(slot) || !roomId || !day || !slot)
    return res.status(400).json({ error: 'roomId, day, and slot are required' });

  // Validate room exists
  const room = rooms.find(r => r.id === roomId);
  if (!room) return res.status(404).json({ error: 'Room not found' });

  // Validate day and slot
  if (!days.includes(day)) return res.status(400).json({ error: 'Invalid day' });
  if (!slots.includes(slot)) return res.status(400).json({ error: 'Invalid slot' });

  // Validate optional fields
  if (subject !== undefined && subject !== null && !isStr(subject))
    return res.status(400).json({ error: 'Invalid subject' });
  if (targetDivision && !DIVISIONS.includes(targetDivision))
    return res.status(400).json({ error: 'Invalid division' });

  // Validate booking date
  if (!isValidDateStr(bookingDate))
    return res.status(400).json({ error: 'A valid booking date is required' });
  const bDate = new Date(bookingDate + 'T00:00:00');
  if (bDate < SEMESTER_START || bDate > SEMESTER_END) {
    return res.status(400).json({
      error: `Bookings are only allowed within the semester (${cfg.SEMESTER_LABEL})`
    });
  }
  // The date's real weekday must match the selected day (Wednesday slot -> a Wednesday date)
  if (days[bDate.getDay() - 1] !== day) {
    return res.status(400).json({ error: `${bookingDate} is not a ${day}` });
  }
  if (cfg.HOLIDAYS.includes(bookingDate)) {
    return res.status(400).json({ error: 'That date is a holiday — bookings are not allowed' });
  }
  // No booking for the past, or for a slot that has already started today
  const now = nowInZone();
  if (bookingDate < now.date)
    return res.status(400).json({ error: 'You cannot book a date that has already passed' });
  if (bookingDate === now.date && slotStartMinutes(slot) <= now.minutes)
    return res.status(400).json({ error: `The ${slot} slot has already started — pick a later slot or date` });

  // Check weekly limit (max WEEKLY_BOOKING_LIMIT extra bookings per teacher per week)
  if (extraBookingsThisWeek(req.user.id).length >= WEEKLY_BOOKING_LIMIT) {
    return res.status(429).json({
      error: `Weekly limit reached: you can only make ${WEEKLY_BOOKING_LIMIT} extra bookings per week`
    });
  }

  const key = `${roomId}|${day}|${slot}`;

  // Check if already booked
  if (bookings[key]) {
    return res.status(409).json({ error: 'Room is already booked for this slot' });
  }

  const cleanSubject = subject ? cleanText(subject, 100) : '';

  // Create booking
  bookings[key] = {
    id: key,
    roomId, day, slot,
    teacherId: req.user.id,
    teacherName: req.user.name,
    subject: cleanSubject || 'Extra Lecture',
    type: 'extra',
    createdAt: new Date().toISOString()
  };

  // Notify students: if booking has a target division, notify only that div; else notify all students
  const targetDiv = targetDivision || null;
  users.filter(u => u.role === 'student' && (!targetDiv || u.division === targetDiv)).forEach(stu => {
    pushNotification({
      id: uuidv4(),
      toUserId: stu.id,
      message: `${req.user.name} booked ${room.name} for ${day} at ${slot}${cleanSubject ? ' — ' + cleanSubject : ''}.`,
      roomName: room.name,
      roomId, day, slot,
      read: false,
      type: 'booking',
      createdAt: new Date().toISOString()
    });
  });

  res.status(201).json({ message: 'Room booked successfully', booking: bookings[key] });
});

// DELETE /api/bookings/:roomId/:day/:slot — cancel a booking
app.delete('/api/bookings/:roomId/:day/:slot', authMiddleware, teacherOnly, (req, res) => {
  const { roomId, day, slot } = req.params;
  const key = `${roomId}|${day}|${slot}`;

  const booking = bookings[key];
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  // Timetable bookings: only the assigned teacher can unbook
  if (booking.type === 'timetable') {
    if (booking.teacherId !== req.user.id)
      return res.status(403).json({ error: 'Only the assigned teacher can unbook a timetabled class' });
    // Allow — fall through to delete below
  } else if (booking.teacherId !== req.user.id) {
    return res.status(403).json({ error: 'You can only cancel your own bookings' });
  }

  // Delete booking
  delete bookings[key];

  // Notify everyone on the waitlist
  const waitlist = waitlists[key] || [];
  const room = rooms.find(r => r.id === roomId);
  const roomName = room ? room.name : roomId;
  waitlist.forEach(w => {
    pushNotification({
      id: uuidv4(),
      toUserId: w.userId,
      message: `${roomName} is now available on ${day} at ${slot}. Book it now!`,
      roomName,
      roomId, day, slot,
      read: false,
      createdAt: new Date().toISOString()
    });
  });

  // Clear waitlist for this slot
  delete waitlists[key];

  res.json({
    message: 'Booking cancelled',
    notifiedCount: waitlist.length
  });
});

// ============================================================
// WAITLIST ROUTES
// ============================================================

// POST /api/waitlist — add to waitlist
app.post('/api/waitlist', authMiddleware, teacherOnly, (req, res) => {
  const { roomId, day, slot } = req.body || {};
  if (!isStr(roomId) || !isStr(day) || !isStr(slot) || !roomId || !day || !slot)
    return res.status(400).json({ error: 'roomId, day, slot required' });

  const key = `${roomId}|${day}|${slot}`;

  // Check room is actually booked
  if (!bookings[key])
    return res.status(400).json({ error: 'Room is already available — just book it!' });

  if (!waitlists[key]) waitlists[key] = [];

  // Check already in waitlist
  if (waitlists[key].find(w => w.userId === req.user.id))
    return res.status(409).json({ error: 'You are already on the waitlist' });

  waitlists[key].push({
    userId: req.user.id,
    userName: req.user.name,
    addedAt: new Date().toISOString()
  });

  res.status(201).json({ message: 'Added to waitlist. You will be notified if the room frees up.' });
});

// DELETE /api/waitlist — remove from waitlist
app.delete('/api/waitlist', authMiddleware, teacherOnly, (req, res) => {
  const { roomId, day, slot } = req.body || {};
  if (!isStr(roomId) || !isStr(day) || !isStr(slot))
    return res.status(400).json({ error: 'roomId, day, slot required' });
  const key = `${roomId}|${day}|${slot}`;

  if (!waitlists[key])
    return res.status(404).json({ error: 'Not on waitlist' });

  waitlists[key] = waitlists[key].filter(w => w.userId !== req.user.id);
  res.json({ message: 'Removed from waitlist' });
});

// GET /api/waitlist/mine — slots where current teacher is on waitlist
app.get('/api/waitlist/mine', authMiddleware, teacherOnly, (req, res) => {
  const myWaits = [];
  Object.entries(waitlists).forEach(([key, list]) => {
    if (list.find(w => w.userId === req.user.id)) {
      const [roomId, day, slot] = key.split('|');
      const room = rooms.find(r => r.id === roomId);
      myWaits.push({ roomId, roomName: room?.name, day, slot });
    }
  });
  res.json({ waitlists: myWaits });
});

// ============================================================
// NOTIFICATIONS ROUTES
// ============================================================

// GET /api/notifications — get my notifications (teacher & student both)
app.get('/api/notifications', authMiddleware, (req, res) => {
  const mine = notifications
    .filter(n => n.toUserId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const unreadCount = mine.filter(n => !n.read).length;
  res.json({ notifications: mine, unreadCount });
});

// PUT /api/notifications/read-all — mark all as read
app.put('/api/notifications/read-all', authMiddleware, (req, res) => {
  notifications
    .filter(n => n.toUserId === req.user.id)
    .forEach(n => n.read = true);
  res.json({ message: 'All notifications marked as read' });
});

// ============================================================
// METADATA ROUTES
// ============================================================

// GET /api/meta — get slots, days, semester info
app.get('/api/meta', authMiddleware, (req, res) => {
  res.json({
    slots, days,
    semester: {
      start: cfg.SEMESTER_START,
      end:   cfg.SEMESTER_END,
      label: cfg.SEMESTER_LABEL,
      weeklyBookingLimit: WEEKLY_BOOKING_LIMIT,
      holidays: cfg.HOLIDAYS
    },
    now: nowInZone()
  });
});

// Health check (no sensitive info)
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Unknown API routes -> JSON 404
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// ============================================================
// FRONTEND — served by this same server (one deploy, same origin, no CORS needed)
// ============================================================
if (fs.existsSync(path.join(FRONTEND_DIR, 'index.html'))) {
  app.use(express.static(FRONTEND_DIR, {
    maxAge: cfg.isProd ? '1h' : 0,
    index: 'index.html'
  }));
} else {
  app.get('/', (req, res) => {
    res.json({ status: 'ClassBook API running', version: '1.0.0' });
  });
}

// ============================================================
// ERROR HANDLER — never leak stack traces to the client
// ============================================================
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
  if (err.type === 'entity.too.large')    return res.status(413).json({ error: 'Request too large' });
  console.error('Server error:', err.message);
  res.status(500).json({ error: 'Something went wrong' });
});

// ============================================================
// START SERVER
// ============================================================
app.listen(cfg.PORT, () => {
  console.log(`\n✅ ClassBook running on port ${cfg.PORT} (${cfg.isProd ? 'production' : 'development'} mode)`);
  console.log(`   Open: http://localhost:${cfg.PORT}\n`);
});
