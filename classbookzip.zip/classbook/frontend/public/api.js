// ============================================================
// API.JS — All API calls to the backend (http://localhost:5000)
// ============================================================

// Same server serves both site and API -> relative URL.
// Local dev with `npx serve public -p 3000` -> talk to backend on port 5000.
const IS_LOCAL_DEV = ['localhost', '127.0.0.1'].includes(location.hostname) && location.port === '3000';
const BASE_URL = IS_LOCAL_DEV ? `${location.protocol}//${location.hostname}:5000/api` : '/api';

// Login session is an httpOnly cookie set by the server — JavaScript never sees the token.
async function apiFetch(path, options = {}) {
  const res = await fetch(BASE_URL + path, {
    ...options,
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  let data = {};
  try { data = await res.json(); } catch { /* non-JSON response */ }
  if (res.status === 401 && typeof currentUser !== 'undefined' && currentUser) {
    window.dispatchEvent(new Event('classbook:session-expired'));
  }
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

// ---- AUTH ----
const Auth = {
  // expectedRole = 'teacher' or 'student' — backend will reject mismatch
  login: (username, password, expectedRole) =>
    apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, expectedRole })
    }),
  me: () => apiFetch('/auth/me'),
  logout: () => apiFetch('/auth/logout', { method: 'POST' })
};

// ---- ROOMS ----
const Rooms = {
  getAll: () => apiFetch('/rooms'),
  getAvailability: (day, slot, minCapacity = 0) =>
    apiFetch(`/rooms/availability?day=${encodeURIComponent(day)}&slot=${encodeURIComponent(slot)}&minCapacity=${minCapacity}`)
};

// ---- BOOKINGS ----
const Bookings = {
  getAll: (day = '') => apiFetch(`/bookings${day ? '?day=' + encodeURIComponent(day) : ''}`),
  getMine: () => apiFetch('/bookings/mine'),
  // targetDivision = 'A' / 'B' / ... / null (null = all students)
  book: (roomId, day, slot, subject, bookingDate, targetDivision) =>
    apiFetch('/bookings', {
      method: 'POST',
      body: JSON.stringify({ roomId, day, slot, subject, bookingDate, targetDivision })
    }),
  cancel: (roomId, day, slot) =>
    apiFetch(`/bookings/${encodeURIComponent(roomId)}/${encodeURIComponent(day)}/${encodeURIComponent(slot)}`, {
      method: 'DELETE'
    })
};

// ---- WAITLIST ----
const Waitlist = {
  add: (roomId, day, slot) =>
    apiFetch('/waitlist', { method: 'POST', body: JSON.stringify({ roomId, day, slot }) }),
  remove: (roomId, day, slot) =>
    apiFetch('/waitlist', { method: 'DELETE', body: JSON.stringify({ roomId, day, slot }) }),
  getMine: () => apiFetch('/waitlist/mine')
};

// ---- NOTIFICATIONS ----
const Notifications = {
  get: () => apiFetch('/notifications'),
  markAllRead: () => apiFetch('/notifications/read-all', { method: 'PUT' })
};

// ---- META ----
const Meta = {
  get: () => apiFetch('/meta')
};
