// ============================================================
// APP.JS — Main frontend application logic
// ============================================================

let currentUser = null;
let META = { slots: [], days: [], semester: null };
let myWaitlistKeys = new Set();
let notifTimer = null;
let SERVER_NOW = null; // server's current date/time (IST) so slot checks don't depend on the device clock

function setServerNow(n) {
  SERVER_NOW = n ? { date: n.date, minutes: n.minutes, at: Date.now() } : null;
}

// { date: 'YYYY-MM-DD', minutes: minutes since midnight } — server time + time elapsed since we last heard from it
function currentNow() {
  const pad = x => String(x).padStart(2, '0');
  if (!SERVER_NOW) {
    const n = new Date();
    return { date: `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`, minutes: n.getHours() * 60 + n.getMinutes() };
  }
  const total = SERVER_NOW.minutes + Math.floor((Date.now() - SERVER_NOW.at) / 60000);
  const d = new Date(`${SERVER_NOW.date}T00:00:00`);
  d.setDate(d.getDate() + Math.floor(total / 1440));
  return { date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`, minutes: total % 1440 };
}

// '08:00-09:00' -> 480
function slotStartMinutes(slot) {
  const [h, m] = slot.split('-')[0].split(':').map(Number);
  return h * 60 + m;
}

// Escape text before putting it inside HTML (stops script injection)
function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

// ============================================================
// SEMESTER HELPERS
// ============================================================
function getDateForDayOfWeek(targetDay, fromDateStr) {
  // Given a date string and a day name (Monday..Friday), find the nearest upcoming date matching that day
  const dayIndex = { Monday:1, Tuesday:2, Wednesday:3, Thursday:4, Friday:5 };
  const base = fromDateStr ? new Date(fromDateStr) : new Date();
  base.setHours(0, 0, 0, 0);
  const diff = (dayIndex[targetDay] - base.getDay() + 7) % 7;
  const result = new Date(base);
  result.setDate(base.getDate() + diff);
  return result.toISOString().split('T')[0];
}

function semesterDates() {
  if (!META.semester) return { start: '2026-07-06', end: '2026-11-21' };
  return { start: META.semester.start, end: META.semester.end };
}

// Get upcoming dates for a day name within the semester (next 8 weeks)
function getDatesForDay(dayName, slot) {
  const dayIndex = { Monday:1, Tuesday:2, Wednesday:3, Thursday:4, Friday:5 };
  const { start, end } = semesterDates();
  const holidays = new Set(META.semester?.holidays || []);
  const endDate = new Date(end + 'T23:59:59');
  const startDate = new Date(start + 'T00:00:00');
  const targetDay = dayIndex[dayName];
  if (targetDay === undefined) return [];

  // Begin from today (server's IST date), or semester start if it hasn't begun yet
  const now = currentNow();
  const from = new Date(`${now.date}T00:00:00`);
  if (from < startDate) from.setTime(startDate.getTime());

  // First date on/after `from` whose real weekday matches (getDay: 0=Sun ... 6=Sat)
  const diff = (targetDay - from.getDay() + 7) % 7;
  const first = new Date(from);
  first.setDate(from.getDate() + diff);

  const dates = [];
  for (let i = 0; i < 30 && dates.length < 8; i++) {
    const d = new Date(first);
    d.setDate(first.getDate() + i * 7);
    if (d > endDate) break;
    // Use local date parts — avoids UTC timezone shift (IST = UTC+5:30)
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    if (holidays.has(iso)) continue;
    // Today's slot that has already started can't be booked
    if (slot && iso === now.date && slotStartMinutes(slot) <= now.minutes) continue;
    dates.push(iso);
  }
  return dates;
}

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

// ============================================================
// INIT
// ============================================================
window.onload = async () => {
  // Session lives in an httpOnly cookie (JS can't read it) — ask the server who we are
  try {
    const data = await Auth.me();
    currentUser = data.user;
    await loadMeta();
    showApp();
  } catch {
    // not signed in — stay on the login screen
  }
};

async function loadMeta() {
  const data = await Meta.get();
  META = data;
  setServerNow(data.now);
}

// ============================================================
// AUTH
// ============================================================
function selectRole(role) {
  document.querySelectorAll('.role-tab').forEach(t =>
    t.classList.toggle('active', t.dataset.role === role)
  );
}

async function doLogin() {
  const username = document.getElementById('login-user').value.trim();
  const password = document.getElementById('login-pass').value;
  const errEl = document.getElementById('login-error');
  errEl.textContent = '';

  // Which tab is active?
  const activeTab = document.querySelector('.role-tab.active');
  const expectedRole = activeTab ? activeTab.dataset.role : 'teacher';

  if (!username || !password) {
    errEl.textContent = 'Please enter username and password';
    return;
  }

  try {
    showBtnLoading('login-btn', true);
    const data = await Auth.login(username, password, expectedRole);
    document.getElementById('login-pass').value = '';
    currentUser = data.user;
    await loadMeta();
    showApp();
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    showBtnLoading('login-btn', false);
  }
}

async function doLogout() {
  try { await Auth.logout(); } catch { /* ignore */ }
  resetToLogin();
}

function resetToLogin() {
  clearInterval(notifTimer);
  currentUser = null;
  myWaitlistKeys = new Set();
  document.getElementById('modal-overlay').classList.add('hidden');
  document.getElementById('auth-screen').classList.remove('hidden');
  document.getElementById('app-screen').classList.add('hidden');
  document.getElementById('login-user').value = '';
  document.getElementById('login-pass').value = '';
  document.getElementById('login-error').textContent = '';
}

function showApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');

  // Set topbar
  const divLabel = currentUser.division ? ` — Div ${currentUser.division}` : '';
  document.getElementById('topbar-name').textContent = currentUser.name + divLabel;
  const badge = document.getElementById('topbar-badge');
  badge.textContent = currentUser.role === 'student'
    ? `Student${currentUser.division ? ' AIML-' + currentUser.division : ''}`
    : 'Teacher';
  badge.className = 'role-badge ' + currentUser.role + '-badge';

  // Show/hide nav
  document.getElementById('nav-teacher').classList.toggle('hidden', currentUser.role !== 'teacher');
  document.getElementById('nav-student').classList.toggle('hidden', currentUser.role !== 'student');

  // Show first page
  const firstPage = currentUser.role === 'teacher' ? 'book' : 'timetable';
  showPage(firstPage);

  // Notification polling for both teachers and students
  updateNotifBadge();
  clearInterval(notifTimer);
  notifTimer = setInterval(updateNotifBadge, 10000);
}

// ============================================================
// NAVIGATION
// ============================================================
function showPage(page) {
  document.querySelectorAll('.nav-item').forEach(n =>
    n.classList.toggle('active', n.dataset.page === page)
  );
  const ca = document.getElementById('content-area');
  ca.innerHTML = '<div class="page-loading">Loading...</div>';

  if (page === 'book')                    renderBook(ca);
  else if (page === 'mybookings')         renderMyBookings(ca);
  else if (page === 'timetable')          renderTimetable(ca);
  else if (page === 'notifications')      renderNotifications(ca);
  else if (page === 'student-notifs')     renderStudentNotifications(ca);
  else if (page === 'rooms-view')         renderRoomsView(ca);
}

// ============================================================
// PAGE: BOOK A ROOM (teacher)
// ============================================================
async function renderBook(ca) {
  const today = META.days[new Date().getDay() - 1] || META.days[0];
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">Book a Room</div>
      <div class="page-sub">Select a day and time slot to see available classrooms</div>
    </div>
    <div class="filter-row">
      <select id="sel-day" data-change="refreshRooms">
        ${META.days.map(d => `<option ${d === today ? 'selected' : ''}>${esc(d)}</option>`).join('')}
      </select>
      <select id="sel-slot" data-change="refreshRooms">
        ${META.slots.map(s => `<option>${esc(s)}</option>`).join('')}
      </select>
      <select id="sel-cap" data-change="refreshRooms">
        <option value="0">Any capacity</option>
        <option value="25">25+ seats</option>
        <option value="35">35+ seats</option>
        <option value="40">40+ seats</option>
        <option value="50">50+ seats</option>
      </select>
    </div>
    <div id="rooms-grid" class="rooms-grid">
      <div class="page-loading">Fetching rooms...</div>
    </div>
  `;
  await refreshRooms();
}

async function refreshRooms() {
  const day = document.getElementById('sel-day')?.value;
  const slot = document.getElementById('sel-slot')?.value;
  const cap = document.getElementById('sel-cap')?.value || '0';
  if (!day || !slot) return;

  const grid = document.getElementById('rooms-grid');
  grid.innerHTML = '<div class="page-loading">Loading rooms...</div>';

  try {
    // Load my waitlist keys to know which rooms I'm watching
    const wlData = await Waitlist.getMine();
    myWaitlistKeys = new Set(wlData.waitlists.map(w => `${w.roomId}|${w.day}|${w.slot}`));

    const data = await Rooms.getAvailability(day, slot, parseInt(cap));
    setServerNow(data.now);
    grid.innerHTML = data.rooms.map(room => buildRoomCard(room, day, slot)).join('');
  } catch (err) {
    grid.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

function roomAttrs(room, day, slot) {
  return `data-room="${esc(room.id)}" data-day="${esc(day)}" data-slot="${esc(slot)}" data-name="${esc(room.name)}"`;
}

function buildRoomCard(room, day, slot) {
  const key = `${room.id}|${day}|${slot}`;
  const isMyBooking = room.booking && room.booking.teacherId === currentUser.id;
  const isOnWaitlist = myWaitlistKeys.has(key);
  const facilitiesList = (room.facilities || []).join(', ');
  const nextDates = getDatesForDay(day, slot);
  const nextDateStr = nextDates.length > 0 ? ' • ' + formatDate(nextDates[0]) : '';
  const attrs = roomAttrs(room, day, slot);

  const waitBtn = isOnWaitlist
    ? `<button class="action-btn cancel-notify-btn" data-action="removeWait" ${attrs}>Remove from Waitlist</button>`
    : `<button class="action-btn notify-btn" data-action="addWait" ${attrs}>Notify Me</button>`;
  const bookerHtml = room.booking
    ? `<div class="room-booker">${esc(room.booking.subject)} — ${esc(room.booking.teacherName)}</div>`
    : '';

  let statusHtml = '', actionsHtml = '';

  if (!room.booking) {
    statusHtml = `<span class="room-status status-free">Available</span>`;
    actionsHtml = `<button class="action-btn book-btn" data-action="openBookModal" ${attrs}>Book Room</button>`;
  } else if (room.booking.type === 'timetable') {
    statusHtml = `<span class="room-status status-timetable">Timetabled</span>${bookerHtml}`;
    // This teacher's own timetabled class — allow unbook
    actionsHtml = room.booking.teacherId === currentUser.id
      ? `<button class="action-btn unbook-btn" data-action="cancelTimetableBooking" ${attrs}>Unbook Timetabled Class</button>`
      : waitBtn;
  } else {
    statusHtml = `<span class="room-status status-booked">Booked</span>${bookerHtml}`;
    actionsHtml = isMyBooking
      ? `<button class="action-btn unbook-btn" data-action="cancelBooking" ${attrs}>Cancel Booking</button>`
      : waitBtn;
  }

  return `
    <div class="room-card">
      <div class="room-name">${esc(room.name)}</div>
      <div class="room-details">
        <span>Cap: ${esc(room.capacity)}</span>
        <span>${esc(room.floor)} Floor</span>
        ${facilitiesList ? `<span>${esc(facilitiesList)}</span>` : ''}
      </div>
      <div style="font-size:12px;color:var(--color-text-secondary);margin-top:4px;margin-bottom:2px">${esc(day)}${esc(nextDateStr)} &bull; ${esc(slot)}</div>
      ${statusHtml}
      ${room.waitlistCount > 0 ? `<div class="waitlist-count">${esc(room.waitlistCount)} teacher(s) waiting</div>` : ''}
      <div class="room-actions">${actionsHtml}</div>
    </div>`;
}

function openBookModal(roomId, day, slot, roomName) {
  const dates = getDatesForDay(day, slot);
  const limit = META.semester ? META.semester.weeklyBookingLimit : 2;
  const semLabel = META.semester ? META.semester.label : '6 Jul – 21 Nov 2026';

  if (dates.length === 0) {
    showToast(`No bookable ${day} ${slot} slot left in this semester.`, 'error');
    return;
  }

  // Division options for notifications
  const divOptions = ['A','B','C','D','E','F'].map(d =>
    `<option value="${d}">AIML-${d}</option>`
  ).join('');

  showModal(
    `Book ${roomName}`,
    `
    <p style="color:var(--color-text-secondary);margin-bottom:0.5rem;font-size:13px">${esc(day)} &bull; ${esc(slot)}</p>
    <p style="color:var(--color-text-tertiary);font-size:11px;margin-bottom:1rem">📅 ${esc(semLabel)} &nbsp;|&nbsp; ⚠️ Max ${esc(limit)} bookings/week</p>
    <div class="form-group">
      <label>Select Date</label>
      <select id="modal-date" style="width:100%;padding:8px 12px;border-radius:6px;border:1px solid var(--color-border);font-size:14px">
        ${dates.map(d => `<option value="${esc(d)}">${esc(day)}, ${esc(formatDate(d))}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label>Subject / Lecture Name</label>
      <input type="text" id="modal-subject" placeholder="e.g. Extra Mathematics Class" maxlength="100" />
    </div>
    <div class="form-group">
      <label>Notify Which Division? <span style="font-size:11px;color:var(--color-text-tertiary)">(optional)</span></label>
      <select id="modal-division" style="width:100%;padding:8px 12px;border-radius:6px;border:1px solid var(--color-border);font-size:14px">
        <option value="">All Students</option>
        ${divOptions}
      </select>
    </div>
    `,
    async () => {
      const subject = document.getElementById('modal-subject').value.trim() || 'Extra Lecture';
      const selectedDate = document.getElementById('modal-date').value;
      const targetDiv = document.getElementById('modal-division').value || null;
      try {
        await Bookings.book(roomId, day, slot, subject, selectedDate, targetDiv);
        const divMsg = targetDiv ? ` AIML-${targetDiv} students notified.` : ' All students notified.';
        showToast(`${roomName} booked for ${formatDate(selectedDate)}!${divMsg}`, 'success');
        await refreshRooms();
      } catch (err) {
        showToast(err.message, 'error');
      }
    },
    'Confirm Booking', 'confirm'
  );
}

async function cancelTimetableBooking(roomId, day, slot, roomName) {
  showModal(
    'Unbook Timetabled Class',
    `<p style="color:var(--color-text-secondary);font-size:13px">Are you sure you want to unbook your timetabled class in <strong>${esc(roomName)}</strong> on ${esc(day)}, ${esc(slot)}?<br><br>This will free the slot and notify anyone on the waitlist.</p>`,
    async () => {
      try {
        const data = await Bookings.cancel(roomId, day, slot);
        showToast(`Timetabled class unbooked. ${data.notifiedCount} teacher(s) notified.`, 'success');
        await refreshRooms();
      } catch (err) {
        showToast(err.message, 'error');
      }
    },
    'Unbook Class', 'danger'
  );
}

async function cancelBooking(roomId, day, slot, roomName) {
  showModal(
    'Cancel Booking',
    `<p style="color:var(--color-text-secondary);font-size:13px">Cancel your booking of <strong>${esc(roomName)}</strong> on ${esc(day)}, ${esc(slot)}? Any teachers on the waitlist will be notified.</p>`,
    async () => {
      try {
        const data = await Bookings.cancel(roomId, day, slot);
        showToast(`Booking cancelled. ${data.notifiedCount} teacher(s) notified.`, 'success');
        await refreshRooms();
      } catch (err) {
        showToast(err.message, 'error');
      }
    },
    'Cancel Booking', 'danger'
  );
}

async function addWait(roomId, day, slot) {
  try {
    await Waitlist.add(roomId, day, slot);
    showToast("Added to waitlist! You'll be notified when the room is free.", 'success');
    await refreshRooms();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function removeWait(roomId, day, slot) {
  try {
    await Waitlist.remove(roomId, day, slot);
    showToast('Removed from waitlist.', 'info');
    await refreshRooms();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// ============================================================
// PAGE: MY BOOKINGS (teacher)
// ============================================================
async function renderMyBookings(ca) {
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">My Bookings</div>
      <div class="page-sub">All rooms you have booked</div>
    </div>
    <div id="weekly-limit-banner" style="display:none;background:#FEF3C7;border:1px solid #F59E0B;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#92400E"></div>
    <div id="bookings-list"><div class="page-loading">Loading...</div></div>
  `;
  try {
    // Show weekly limit info
    let weeklyCount = 0, weeklyLimit = META.semester?.weeklyBookingLimit || 2;
    try {
      const wc = await apiFetch('/bookings/weekly-count');
      weeklyCount = wc.count; weeklyLimit = wc.limit;
    } catch {}
    const banner = document.getElementById('weekly-limit-banner');
    banner.style.display = 'block';
    banner.innerHTML = `📅 This week: <strong>${esc(weeklyCount)}/${esc(weeklyLimit)}</strong> extra bookings used &nbsp;|&nbsp; Semester: ${esc(META.semester?.label || '6 Jul – 21 Nov 2026')}`;

    const data = await Bookings.getMine();
    const list = document.getElementById('bookings-list');
    if (data.bookings.length === 0) {
      list.innerHTML = '<div class="empty-state"><div class="empty-icon">◈</div><p>No active bookings</p></div>';
      return;
    }
    list.innerHTML = data.bookings.map(b => {
      const typeStyle = b.type === 'timetable'
        ? 'background:#FAEEDA;color:#854F0B'
        : 'background:#E6F1FB;color:#185FA5';
      const canUnbook = b.type === 'timetable' || b.type === 'extra';
      const unbookLabel = b.type === 'timetable' ? 'Unbook Timetabled' : 'Cancel';
      const unbookAction = b.type === 'timetable' ? 'cancelTimetableBooking' : 'cancelAndRefreshMyBookings';
      return `
        <div class="booking-item">
          <div class="booking-info">
            <div class="broom">${esc(b.roomId)} — ${esc(b.subject)}</div>
            <div class="btime">${esc(b.day)} &bull; ${esc(b.slot)}</div>
            <span class="btype" style="${typeStyle}">${b.type === 'timetable' ? 'Timetabled' : 'Extra Lecture'}</span>
          </div>
          <button class="action-btn unbook-btn" data-action="${unbookAction}"
            data-room="${esc(b.roomId)}" data-day="${esc(b.day)}" data-slot="${esc(b.slot)}" data-name="${esc(b.roomId)}">${unbookLabel}</button>
        </div>`;
    }).join('');
  } catch (err) {
    ca.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

async function cancelAndRefreshMyBookings(roomId, day, slot, roomName) {
  showModal(
    'Cancel Booking',
    `<p style="color:var(--color-text-secondary);font-size:13px">Cancel booking for ${esc(roomId)} on ${esc(day)}, ${esc(slot)}?</p>`,
    async () => {
      try {
        const data = await Bookings.cancel(roomId, day, slot);
        showToast(`Cancelled. ${data.notifiedCount} teacher(s) notified.`, 'success');
        showPage('mybookings');
      } catch (err) {
        showToast(err.message, 'error');
      }
    },
    'Cancel Booking', 'danger'
  );
}

// ============================================================
// PAGE: TIMETABLE
// ============================================================
async function renderTimetable(ca) {
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">Weekly Timetable</div>
      <div class="page-sub">
        <span class="legend-item"><span class="legend-dot timetable-dot"></span>Timetabled class</span>
        <span class="legend-item"><span class="legend-dot extra-dot"></span>Extra lecture</span>
        <span class="legend-item"><span class="legend-dot free-dot"></span>Free</span>
      </div>
    </div>
    <div class="day-tabs">
      ${META.days.map((d, i) => `<button class="day-tab ${i === 0 ? 'active' : ''}" data-action="switchTTDay" data-day="${esc(d)}">${esc(d)}</button>`).join('')}
    </div>
    <div id="tt-container"><div class="page-loading">Loading timetable...</div></div>
  `;
  await loadTimetableDay(META.days[0]);
}

async function switchTTDay(day, btn) {
  document.querySelectorAll('.day-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  await loadTimetableDay(day);
}

async function loadTimetableDay(day) {
  const container = document.getElementById('tt-container');
  container.innerHTML = '<div class="page-loading">Loading...</div>';
  try {
    const data = await Bookings.getAll(day);
    const bookingMap = {};
    data.bookings.forEach(b => { bookingMap[`${b.roomId}|${b.slot}`] = b; });

    // Fetch rooms
    const roomData = await Rooms.getAll();
    const rooms = roomData.rooms;

    container.innerHTML = `
      <div class="tt-wrap">
        <table class="tt-table">
          <thead>
            <tr>
              <th class="tt-room-col">Room</th>
              ${META.slots.map(s => `<th>${esc(s)}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${rooms.map(r => `
              <tr>
                <td class="tt-room-col"><strong>${esc(r.name)}</strong><br><span style="font-size:10px;color:var(--color-text-tertiary)">${esc(r.capacity)} seats</span></td>
                ${META.slots.map(s => {
                  const b = bookingMap[`${r.id}|${s}`];
                  if (!b) return `<td class="tt-free">—</td>`;
                  if (b.type === 'timetable') return `<td class="tt-booked">${esc(b.subject)}<br><span class="tt-teacher">${esc(b.teacherName)}</span></td>`;
                  return `<td class="tt-extra">Extra<br><span class="tt-teacher">${esc(b.teacherName)}</span></td>`;
                }).join('')}
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  } catch (err) {
    container.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

// ============================================================
// PAGE: NOTIFICATIONS (teacher)
// ============================================================
async function renderNotifications(ca) {
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">Notifications</div>
      <div class="page-sub">Room availability alerts</div>
    </div>
    <div id="notif-list"><div class="page-loading">Loading...</div></div>
  `;
  try {
    const data = await Notifications.get();
    await Notifications.markAllRead();
    updateNotifBadge();
    const list = document.getElementById('notif-list');
    if (data.notifications.length === 0) {
      list.innerHTML = '<div class="empty-state"><div class="empty-icon">◎</div><p>No notifications yet</p></div>';
      return;
    }
    list.innerHTML = data.notifications.map(n => `
      <div class="notif-item ${n.read ? '' : 'notif-unread'}">
        <div class="notif-icon">${n.read ? '○' : '●'}</div>
        <div class="notif-body-wrap">
          <div class="notif-title">${esc(n.roomName)} is now available</div>
          <div class="notif-text">${esc(n.message)}</div>
          <div class="notif-time">${new Date(n.createdAt).toLocaleString()}</div>
          <button class="action-btn book-btn" style="margin-top:6px;padding:4px 12px;font-size:11px"
            data-action="openBookModal" data-room="${esc(n.roomId)}" data-day="${esc(n.day)}" data-slot="${esc(n.slot)}" data-name="${esc(n.roomName)}">
            Book Now
          </button>
        </div>
      </div>`).join('');
  } catch (err) {
    ca.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

async function updateNotifBadge() {
  if (!currentUser) return;
  try {
    const data = await Notifications.get();
    const badge = document.getElementById('notif-badge');
    const studentBadge = document.getElementById('student-notif-badge');
    const count = data.unreadCount || 0;
    if (badge) {
      badge.textContent = count || '';
      badge.style.display = count > 0 ? 'inline-flex' : 'none';
    }
    if (studentBadge) {
      studentBadge.textContent = count || '';
      studentBadge.style.display = count > 0 ? 'inline-flex' : 'none';
    }
  } catch {}
}

// ============================================================
// PAGE: ROOMS VIEW (student)
// ============================================================
async function renderRoomsView(ca) {
  const today = META.days[new Date().getDay() - 1] || META.days[0];
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">Room Status</div>
      <div class="page-sub">Check which rooms are free right now</div>
    </div>
    <div class="filter-row">
      <select id="sv-day" data-change="refreshStudentView">
        ${META.days.map(d => `<option ${d === today ? 'selected' : ''}>${esc(d)}</option>`).join('')}
      </select>
      <select id="sv-slot" data-change="refreshStudentView">
        ${META.slots.map(s => `<option>${esc(s)}</option>`).join('')}
      </select>
    </div>
    <div id="sv-grid" class="rooms-grid"><div class="page-loading">Loading...</div></div>
  `;
  await refreshStudentView();
}

async function refreshStudentView() {
  const day = document.getElementById('sv-day')?.value;
  const slot = document.getElementById('sv-slot')?.value;
  const grid = document.getElementById('sv-grid');
  if (!day || !slot) return;
  grid.innerHTML = '<div class="page-loading">Loading...</div>';
  try {
    const data = await Rooms.getAvailability(day, slot, 0);
    setServerNow(data.now);
    grid.innerHTML = data.rooms.map(room => {
      let statusHtml = '';
      if (!room.booking) statusHtml = `<span class="room-status status-free">Available</span>`;
      else if (room.booking.type === 'timetable') statusHtml = `<span class="room-status status-timetable">Timetabled</span><div class="room-booker">${esc(room.booking.subject)} — ${esc(room.booking.teacherName)}</div>`;
      else statusHtml = `<span class="room-status status-booked">Extra Lecture</span><div class="room-booker">${esc(room.booking.subject)} — ${esc(room.booking.teacherName)}</div>`;
      return `
        <div class="room-card">
          <div class="room-name">${esc(room.name)}</div>
          <div class="room-details"><span>Cap: ${esc(room.capacity)}</span><span>${esc(room.floor)} Floor</span></div>
          ${statusHtml}
        </div>`;
    }).join('');
  } catch (err) {
    grid.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

// ============================================================
// PAGE: NOTIFICATIONS (student)
// ============================================================
async function renderStudentNotifications(ca) {
  ca.innerHTML = `
    <div class="page-header">
      <div class="page-title">Class Notifications</div>
      <div class="page-sub">Updates from your teachers</div>
    </div>
    <div id="student-notif-list"><div class="page-loading">Loading...</div></div>
  `;
  try {
    const data = await Notifications.get();
    await Notifications.markAllRead();
    updateNotifBadge();
    const list = document.getElementById('student-notif-list');
    if (data.notifications.length === 0) {
      list.innerHTML = '<div class="empty-state"><div class="empty-icon">◎</div><p>No notifications yet</p></div>';
      return;
    }
    list.innerHTML = data.notifications.map(n => `
      <div class="notif-item ${n.read ? '' : 'notif-unread'}">
        <div class="notif-icon">${n.read ? '○' : '●'}</div>
        <div class="notif-body-wrap">
          <div class="notif-title">${esc(n.roomName || 'Room Update')}</div>
          <div class="notif-text">${esc(n.message)}</div>
          <div class="notif-time">${new Date(n.createdAt).toLocaleString()}</div>
        </div>
      </div>`).join('');
  } catch (err) {
    ca.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  }
}

// ============================================================
// ============================================================
function showModal(title, bodyHtml, onConfirm, confirmLabel = 'Confirm', type = 'confirm') {
  const overlay = document.getElementById('modal-overlay');
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  const confirmBtn = document.getElementById('modal-confirm');
  confirmBtn.textContent = confirmLabel;
  confirmBtn.className = 'modal-btn modal-btn-' + type;
  overlay.classList.remove('hidden');
  overlay._cb = onConfirm;
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('modal-cancel').onclick = closeModal;
  document.getElementById('modal-confirm').onclick = async () => {
    const overlay = document.getElementById('modal-overlay');
    if (overlay._cb) await overlay._cb();
    closeModal();
  };
  document.getElementById('modal-overlay').onclick = (e) => {
    if (e.target === document.getElementById('modal-overlay')) closeModal();
  };
  document.getElementById('login-pass').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
});

function closeModal() {
  document.getElementById('modal-overlay').classList.add('hidden');
}

// ============================================================
// TOAST
// ============================================================
let toastTimer;
function showToast(msg, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = 'toast toast-' + type + ' show';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}

// ============================================================
// UTILS
// ============================================================
function showBtnLoading(id, loading) {
  const btn = document.getElementById(id);
  if (btn) btn.textContent = loading ? 'Signing in...' : 'Sign In';
}

// ============================================================
// EVENTS — one delegated listener (no inline onclick, so strict CSP can stay on)
// ============================================================
const CLICK_ACTIONS = {
  selectRole: el => selectRole(el.dataset.role),
  login: () => doLogin(),
  logout: () => doLogout(),
  showPage: el => showPage(el.dataset.page),
  openBookModal: el => openBookModal(el.dataset.room, el.dataset.day, el.dataset.slot, el.dataset.name),
  cancelTimetableBooking: el => cancelTimetableBooking(el.dataset.room, el.dataset.day, el.dataset.slot, el.dataset.name),
  cancelBooking: el => cancelBooking(el.dataset.room, el.dataset.day, el.dataset.slot, el.dataset.name),
  cancelAndRefreshMyBookings: el => cancelAndRefreshMyBookings(el.dataset.room, el.dataset.day, el.dataset.slot, el.dataset.name),
  addWait: el => addWait(el.dataset.room, el.dataset.day, el.dataset.slot),
  removeWait: el => removeWait(el.dataset.room, el.dataset.day, el.dataset.slot),
  switchTTDay: el => switchTTDay(el.dataset.day, el)
};
const CHANGE_ACTIONS = {
  refreshRooms: () => refreshRooms(),
  refreshStudentView: () => refreshStudentView()
};

document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (el && CLICK_ACTIONS[el.dataset.action]) CLICK_ACTIONS[el.dataset.action](el);
});
document.addEventListener('change', e => {
  const el = e.target.closest('[data-change]');
  if (el && CHANGE_ACTIONS[el.dataset.change]) CHANGE_ACTIONS[el.dataset.change](el);
});

// Token expired / revoked while using the app
window.addEventListener('classbook:session-expired', () => {
  resetToLogin();
  document.getElementById('login-error').textContent = 'Session expired — please sign in again';
});
